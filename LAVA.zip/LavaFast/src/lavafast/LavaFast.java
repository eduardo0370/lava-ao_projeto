package lavafast;

import java.util.ArrayList;
import models.Proprietario;
import models.Veiculo;
import views.TelaInicial;


public class LavaFast {

    public static ArrayList<Proprietario> listaProprietario = new ArrayList<>(); //FAKE DB
    public static ArrayList<Veiculo> listaVeiculo = new ArrayList<>(); //FAKE DB
    
    public static void main(String[] args) {
        TelaInicial t = new TelaInicial();
        t.setVisible(true);
    }
    
}
