package models;


public class Horarios {
    public String hora;
    public String dia;
    public String servico;
    public String veiculo;
   
    public Horarios (String hora, String dia, String servico,String veiculo) {
        this.hora = hora;
        this.dia = dia;
        this.servico = servico;
        this.veiculo = veiculo;
    
}
}

