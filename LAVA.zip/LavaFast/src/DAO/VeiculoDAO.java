package DAO;

import Utils.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import models.Veiculo;

public class VeiculoDAO {
     public static int InserirVeiculo(Veiculo veiculo) {
        String sql = "INSERT INTO veiculos (marca, modelo, placa) VALUES (?,?,?)";
        Connection conexao = Conexao.CriarConexao(); // CONEXÃO BANCO
        try {
            PreparedStatement stm; // CRIA VARIAVEL STATEMENT/HOMOLOGANDO
            stm = conexao.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            stm.setString(1, veiculo.getMarca());
            stm.setString(2, veiculo.getModelo());
            stm.setString(3, veiculo.getPlaca());
    
            stm.execute();
            ResultSet rs = stm.getGeneratedKeys();
            rs.next();
            return rs.getInt(1);
        } catch (SQLException e) {
            System.out.println("NÃO FOI POSSÍVEL FAZER A INSERÇÃO DO USUÁRIO" + e);
        }
        return 0;
    }
     
    public static ArrayList<Veiculo> BuscarTodosVeiculos(){
        String sql = "SELECT * FROM veiculos ORDER BY codigo";
        Connection conexao = Conexao.CriarConexao();
              
        ArrayList<Veiculo> listaVeiculo = new ArrayList<>();
        try {
            PreparedStatement stm = conexao.prepareStatement(sql);
            ResultSet resultado = stm.executeQuery();
            while (resultado.next()) {
                int codigo = resultado.getInt("codigo");
                String modelo = resultado.getString("modelo");
                String marca = resultado.getString("marca");
                String placa = resultado.getString("placa");  
                Veiculo v1 = new Veiculo(codigo, modelo, marca, placa);
                listaVeiculo.add(v1);
            }
            return listaVeiculo;
        } catch (SQLException e) {
            System.out.println("NÃO FOI POSSÍVEL BUSCAR DADOS" + e);
        }

        return listaVeiculo;  
    }
}
