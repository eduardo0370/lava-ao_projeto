
package DAO;

import Utils.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import models.Proprietario;


public class ProprietarioDAO {
     public static int InserirProprietario( Proprietario  proprietario) {
        String sql = "INSERT INTO  Proprietarios (nome, endereco, cpf) VALUES (?,?,?)";
        Connection conexao = Conexao.CriarConexao(); // CONEXÃO BANCO
        try {
            PreparedStatement stm; // CRIA VARIAVEL STATEMENT/HOMOLOGANDO
            stm = conexao.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);
            stm.setString(1,  proprietario.getNome());
            stm.setString(2,  proprietario.getEndereco());
            stm.setString(3,  proprietario.getCpf());
    
            stm.execute();
            ResultSet rs = stm.getGeneratedKeys();
            rs.next();
            return rs.getInt(1);
        } catch (SQLException e) {
            System.out.println("NÃO FOI POSSÍVEL FAZER A INSERÇÃO DO USUÁRIO" + e);
        }
        return 0;
    }
     

}
    

